(function() {
	ex.namespace("ex.display");
	
	var Renderable = new ex.Class({
		constructor: function() {
			
		},
		
		update: function(dt) {
			
		},
		
		render: function(context, camX, camY) {
			
		}
	});
	
	window.ex.display.Renderable = Renderable;
	
}());

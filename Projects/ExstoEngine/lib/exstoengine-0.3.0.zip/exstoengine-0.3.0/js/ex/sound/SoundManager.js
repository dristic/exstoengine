ex.using([
   
], function () {
	ex.namespace("ex.sound");
	
	ex.sound.SoundManager = new ex.Class({
		
	});
});
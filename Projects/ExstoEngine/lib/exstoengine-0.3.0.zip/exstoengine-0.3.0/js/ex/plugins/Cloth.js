/*
 * Cloth Simulation Plugin
 * 
 * Requirements:
 * - High quality
 * - very efficient
 * 
 * - variable density
 * - stretching
 * - tearing
 * - line, rect, and poly
 */ 
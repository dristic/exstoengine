(function() {
	window.ex.base = window.ex.base || {};
	
	var Component = new ex.Class({
		constructor: function() {
			
		},
		
		update: function(dt) {
			
		},
		
		name: "Component"
	});
	
	window.ex.base.Component = Component;
	
}());
